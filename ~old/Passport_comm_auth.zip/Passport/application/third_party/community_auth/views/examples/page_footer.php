</body>
</html>

<?php

/* End of file page_footer.php */
/* Location: /views/examples/page_footer.php */