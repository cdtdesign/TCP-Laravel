    <div id="footer" class="container">
		<p class="center"><b>&copy; 2015 Traveling Children Project, LLC. All rights reserved. <a href="https://www.google.com/intl/en/chrome/browser/desktop/index.html#brand=CHMB&utm_campaign=en&utm_source=en-ha-na-us-sk&utm_medium=ha" alt="Google Chrome" target="_blank"><img id="chrome" src="/ASL/Passport/assets/img/chrome.png" /></a> Best viewed with <a href="https://www.google.com/intl/en/chrome/browser/desktop/index.html#brand=CHMB&utm_campaign=en&utm_source=en-ha-na-us-sk&utm_medium=ha" alt="Google Chrome" target="_blank">Google Chrome</a>.</b></p>
	</div><!-- /.container -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/ASL/Passport/assets/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="/ASL/Passport/assets/css/custom3.css">
  </body>
</html>