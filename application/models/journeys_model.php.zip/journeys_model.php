<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Journeys_model extends CI_Model {
	
	public $fname;
	public $title;
	public $name;
	public $date;
	public $body;
	public $htags;
	public $img;
	
	public function __construct()
    {
            // Call the CI_Model constructor
            parent::__construct();
    }
	
	public function insert_entry()
	{
			$data = array(
					'fname' => $fname,
			        'title' => $title,
			        'name' 	=> $name,
			        'date' 	=> $date,
					'body' 	=> $body,
					'htags'	=> $htags,
					'img'	=> $img
			);

			$this->db->insert('journeys', $data);
	}
}