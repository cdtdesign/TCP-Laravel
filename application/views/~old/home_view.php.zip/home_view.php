<div class="container center">
	<!-- <h1>TCP Passport</h1> -->
	<img src="/ASL/Passport/assets/img/tcp-crest-yllwshirt.svg" class="crest" />
	<div class="center">
	<p class="lead center">Welcome to the Traveling Children Project Passport! Your passport to fun experiences!</p>
	<form class="destination-form" role="search">
		<div class="destination-search">
			<select name="destinations">
			  <option name="active" value="Active">Active</option>
			  <option name="create" value="Creative">Creative</option>
			  <option name="fun" value="Fun">Fun</option>
			  <option name="learn" value="Learning">Learning</option>
			  <option name="outdoor" value="Outdoor">Outdoor</option>
			  <option name="perf" value="Performance">Performance</option>
			  <option name="read" value="Reading">Reading</option>
			  <option name="taste" value="Tasty">Tasty</option>
			  <option name="tech" value="Technology">Technology</option>
			</select>
			<input type="text" placeholder="Destination Location (City, ST)"> <!-- class="form-control" -->
			<button type="submit">Search</button> <!-- class="btn btn-default" -->
        </div>
	</form>
	<ul id="destination-panel" class="destination-buttons center">
		<li class="lefty"><a href="#">Active</a></li><li><a href="#">Creative</a></li><li><a href="#">Fun</a></li><li><a href="#">Learning</a></li><li><a href="#">Outdoor</a></li><li><a href="#">Performance</a></li><li><a href="#">Reading</a></li><li><a href="#">Tasty</a></li><li class="righty"><a href="#">Technology</a></li>
	</ul>
	</div><!-- /.center -->
</div><!-- /.container -->